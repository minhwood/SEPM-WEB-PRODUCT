<?php
include("navigation.php");?>
    <div class="side-nav"> 
        <div><h3 class="cat-title">Categories</h3>
        <a class="cat-box" href="display.php?type=desktops" target="Test">Desktops</a>
        <a class="cat-box" href="display.php?type=laptops" target="Test">Laptops</a>
        <a class="cat-box" href="display.php?type=parts" target="Test">Desktop & Laptop Parts</a>
        <a class="cat-box" href="display.php?type=other_parts" target="Test">Other Accessories</a></div>
    </div>
    <div>
        
        <iframe src="firstpage.php" class="iframe" name="Test">
        </iframe>

    </div>

    <footer><h3>Melbourne Tech Store</h3></footer>
    

</body>
</html>